package org.itstep;

public class Main {
    public static void main(String[] args) {

        Work work = new Work();
        work.run();

    }
}